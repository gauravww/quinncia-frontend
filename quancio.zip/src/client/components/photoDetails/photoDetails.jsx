import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getPhoto, getPhotoById } from "../../redux/reducers/index";
import { Link, useNavigate } from "react-router-dom";
import "./photoDetails.css";
import Pagination from "react-bootstrap/Pagination";

const PhotosList = () => {
    const [userDetails,setUserDetails]= useState(null)
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const photos = useSelector((state) => state.photo);
    console.log(photos?.photoList, "-------photos ----func---detail");
    const photoId = new URLSearchParams(location.search).get("id");
    console.log("---photo id---",photoId);

    useEffect(() => {
        dispatch(getPhotoById(photoId));
        // const found = photos.photoList.find(obj => {
        //     return obj._id === photoId;
        //   });
        // console.log(found,"========find")
    }, [dispatch]);
    // useEffect(()=>{
    //     let det = photos.filter(d=>d._id===photoId)
    //     console.log("---det---",det);
    //     setUserDetails(det[0])

    // },[photos.length])

    const DeleteUserData = (id) => {
        var result = window.confirm("Want to delete?");
        if (result) {
            dispatch(deleteUser({ id: id }));
        }
    };

    return (
        <>
            <div className="container my-3">
                <div className="row align-items-center">
                    <div className="col">
                        <h3>
                            {" "}
                            <i className="bi bi-arrow-left me-2" onClick={() => navigate("/photo/many")}></i>User Photo Details
                        </h3>
                    </div>

                    <div className="col-auto">
                        <button className="btn btn-primary" onClick={() => navigate("/photo/")}>Add More</button>
                    </div>
                </div>

                <div className="">
                    <div className="row my-3">
                        <div className="col-sm-4">
                            <div className=" mb-3">
                                <img
                                    className="w-full rounded"
                                    src={`http://localhost:3000/public/${photos?.photoList?.imageUrl}`}
                                    alt=""
                                />
                            </div>
                        </div>

                        <div className="col-sm-8">
                            <div>
                                <div className="mb-3">
                                    {photos?.photoList?
                                        photos?.photoList?.tagIDs?.map(d=>( <span className="badge text-bg-primary tag-box">{d}</span>)):null

                                    }
                                    {/* <span className="badge text-bg-primary tag-box">#Cute</span>
                                    <span className="badge text-bg-primary tag-box">#Cute</span>
                                    <span className="badge text-bg-primary tag-box">#Cute</span>
                                    <span className="badge text-bg-primary tag-box">#Cute</span> */}
                                </div>

                                <div>
                                    <h2>Ravindra Pawar</h2>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div>
                            <h5>Comments {photos?.photoList?.commentIDs?.length}</h5>

                            <div className="mb-3">
                                <div className="row ">
                                    <div className="col-auto">
                                        <img src="https://img.icons8.com/ios/50/000000/user-male-circle.png" />
                                    </div>
                                    <div className="col-4">
                                        <input
                                            type="text"
                                            className="form-control user-comments-box"
                                            placeholder="Enter your Comments"
                                            name=""
                                            id=""
                                        />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <div className="mb-3">
                                    <div className="row ">
                                        <div className="col-auto">
                                            <img src="https://img.icons8.com/color/48/000000/user-male-circle--v1.png" />
                                        </div>
                                        <div className="col-11">
                                            <div className="commenet-text">
                                                <h5 className="m-0">
                                                    Sir Ravindra Jadeja{" "}
                                                    <span className="time-comment">(1 Month Ago)</span>
                                                </h5>
                                                
                                                <p>{photos?.photoList?.commentIDs}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* <div className="mb-3">
                                    <div className="row ">
                                        <div className="col-auto">
                                            <img src="https://img.icons8.com/color/48/000000/user-male-circle--v1.png" />
                                        </div>
                                        <div className="col-11">
                                            <div className="commenet-text">
                                                <h5 className="m-0">
                                                    Sir Ravindra Jadeja{" "}
                                                    <span className="time-comment">(1 Month Ago)</span>
                                                </h5>
                                                <p>Duniya ka Best Fielder Kon</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="mb-3">
                                    <div className="row ">
                                        <div className="col-auto">
                                            <img src="https://img.icons8.com/color/48/000000/user-male-circle--v1.png" />
                                        </div>
                                        <div className="col-11">
                                            <div className="commenet-text">
                                                <h5 className="m-0">
                                                    Sir Ravindra Jadeja{" "}
                                                    <span className="time-comment">(1 Month Ago)</span>
                                                </h5>
                                                <p>Duniya ka Best Fielder Kon</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="mb-3">
                                    <div className="row ">
                                        <div className="col-auto">
                                            <img src="https://img.icons8.com/color/48/000000/user-male-circle--v1.png" />
                                        </div>
                                        <div className="col-11">
                                            <div className="commenet-text">
                                                <h5 className="m-0">
                                                    Sir Ravindra Jadeja{" "}
                                                    <span className="time-comment">(1 Month Ago)</span>
                                                </h5>
                                                <p>Duniya ka Best Fielder Kon</p>
                                            </div>
                                        </div>
                                    </div>
                                </div> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default PhotosList;
