export const COUNTER_INCREMENT = 'feature/counter/increment';

export const COUNTER_DECREMENT = 'feature/counter/decrement';
